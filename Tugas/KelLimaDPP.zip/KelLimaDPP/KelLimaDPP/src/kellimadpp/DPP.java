package kellimadpp;
/**
 * Anggota Kelompok 5 2KS3:
 * Pandya Almastiana Alifka 222011620
 * Moch. Daffa' AlFaris     222011622
 * Rahmad Setiya Budi       222011623
 * Amanda Christina Saragih 222011650
 * Nur Aini Adilah          222011676
 */

    public class DPP {
    private String kolom12;
    private String kolom13;

    public DPP() {
    }

    public DPP(String kolom12, String kolom13) {
        this.kolom12 = kolom12;
        this.kolom13 = kolom13;
    }

    public String getKolom12() {
        return kolom12;
    }

    public void setKolom12(String kolom12) {
        this.kolom12 = kolom12;
    }

    public String getKolom13() {
        return kolom13;
    }

    public void setKolom13(String kolom13) {
        this.kolom13 = kolom13;
    }
}