package designpatterns.decorator.notifier;

/**
 *
 * @author user
 */
public interface Notifier {
    public void send(String message);
}
