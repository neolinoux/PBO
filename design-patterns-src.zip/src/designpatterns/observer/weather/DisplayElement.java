package designpatterns.observer.weather;

/**
 *
 * @author user
 */
public abstract class DisplayElement {
    public abstract void display();
}
