package twitterapp.tweet;

public interface Follower {
    public void update(TweetData tweet);
}
