package javaio;

import java.io.*;
public class BufferedWriterExample {
    public static void main(String[] args) {
        FileWriter writer = new FileWriter("testout.txt");
        BufferedWriter buffer = new BufferedWriter(writer);
        buffer.write("Welcome to javaTpoint.");
        buffer.close();
        System.out.println("Success");
    }
}
